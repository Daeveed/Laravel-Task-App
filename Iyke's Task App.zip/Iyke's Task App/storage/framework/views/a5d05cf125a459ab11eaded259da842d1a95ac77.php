<?php $__env->startSection('killer'); ?>

<?php $__env->startSection('title', '| Edit Task'); ?>

  <div class="row">
    <div class="col-md-8 col-md-offset-2">
            <?php echo Form::model($task,['route'=>['add_task.update',$task->id],'method'=>'patch','class'=>'form']); ?>

            <div class="form-group<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
            <?php echo Form::label('Name of Task'); ?>


            <?php echo Form::text('name',null,['class'=>'form-control']); ?>

                <?php if($errors->has('name')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('name')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
            <?php echo Form::label('Status'); ?>


            <?php echo Form::select('status',['completed'=>'Completed','uncompleted'=>'Un-completed'],$task->status,['class'=>'form-control']); ?>

            <br>

            <div class="row">
					    <div class="col-sm-3">
              <?php echo Form::submit('Update',['class'=>'btn btn-primary btn-block']); ?>

              <?php echo Form::close(); ?>

              </div>

              <div class="col-sm-3">
              <?php echo Html::linkRoute('add_task.index', 'Cancel', array($task->id), array('class' => 'btn btn-danger btn-block')); ?>

            </div>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>