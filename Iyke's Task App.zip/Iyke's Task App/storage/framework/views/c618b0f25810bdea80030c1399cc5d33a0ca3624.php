<!--Content to serve-->
<?php $__env->startSection('killer'); ?>

<?php $__env->startSection('title', '| Homepage'); ?>

  <div class="row">
    <div class="col-md-12">
      <div class="jumbotron">
        <h1 class="text-center">My Task App</h1>
        <h2 class="text-center"> Thanks For Using This Task App... </h2>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.parent', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>