@extends('layouts.parent')
<!--Content to serve-->
@section('killer')

@section('title', '| Homepage')

  <div class="row">
    <div class="col-md-12">
      <div class="jumbotron">
        <h1 class="text-center">My Task App</h1>
        <h2 class="text-center"> Thanks For Using This Task App... </h2>
      </div>
    </div>
  </div>
@endsection
